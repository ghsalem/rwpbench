export uid=sh/Welcome1234!@emeafrgsalem_high
sqlldr userid=$uid file=chan_v3.dat control=chan_v3.ctl direct=true
sqlldr userid=$uid file=coun_v3.dat control=coun_v3.ctl direct=true
sqlldr userid=$uid file=cust1v3.dat control=cust_v3.ctl direct=true
sqlldr userid=$uid file=prod1v3.dat control=prod_v3.ctl direct=true
sqlldr userid=$uid file=prom1v3.dat control=prom_v3.ctl direct=true
sqlldr userid=$uid file=sale1v3.dat control=sale_v3.ctl direct=true
sqlldr userid=$uid file=time_v3.dat control=time_v3.ctl direct=true
