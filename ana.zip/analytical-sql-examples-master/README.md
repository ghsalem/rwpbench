<!--
rem  ****************************************************************
rem  Version 1.0 Dec 7, 2014
rem  Readme for analytical SQL Respository
rem  Author Keith Laker, Snr Principal Product Manager, Oracle
rem  ****************************************************************
rem

-->
analytical-sql-examples
=======================
This reopistory is now decommissioned. All scripts are now available as tutorials on livesql.oracle.com.
