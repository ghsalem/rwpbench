rem  ****************************************************************
rem  Version 1.0 Dec 7, 2014
rem  Script for demonstrating the features of analytical SQL
rem  Author Keith Laker, Snr Principal Product Manager, Oracle
rem
rem  ****************************************************************
rem
rem If you need to reset your buffer cache during this session, i.e.
rem when you are reviewing explain plans etc then you might find
rem this commmand usefyul:
rem
rem alter system flush buffer_cache;
rem



rem  start with a basic report showing a running total for a specific product sub-category
rem  and for a specific year. The report will show the amount sold in each month
rem  and the final column will create a running total.

SELECT
 prod_subcategory_desc AS category,
 calendar_month_desc AS month,
 amount_sold AS sales,
 SUM(amount_sold) OVER (ORDER BY calendar_month_id) AS cum_sales
FROM PRODCAT_MONTHLY_SALES
WHERE prod_subcategory_desc ='Cameras'
AND calendar_year_id =:CAL_YEAR;

